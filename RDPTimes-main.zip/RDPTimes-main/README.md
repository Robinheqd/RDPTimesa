# CursoRDP
CursoRDP

Instructions:

Go to Actions/Workflows

Click "Windows"

Click "Run workflow"

Get a Command from https://remotedesktop.google.com/headless (use a PowerShell command)

Enter a six-digit pin

Run workflow

You're done!

Your RDP will start in 1-2 minutes.
